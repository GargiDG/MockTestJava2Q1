package com.gargi.overridenmethods;

public class Animal {
	
	public void makeSound() {
		System.out.println("Animal making sound doesn't make sense until specified which animal");
	}
	

}
