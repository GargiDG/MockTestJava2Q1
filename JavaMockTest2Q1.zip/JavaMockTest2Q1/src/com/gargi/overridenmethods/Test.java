package com.gargi.overridenmethods;

public class Test {

	public static void main(String[] args) {
		Dog d = new Dog();
		d.makeSound();
		Cat c = new Cat();
		c.makeSound();
		Cow cw = new Cow();
		cw.makeSound();

	}

}
