package com.gargi.overridenmethods;

public class Cat extends Animal{
	public void makeSound() {
		System.out.println("Cat says meow");
	}
	

}
