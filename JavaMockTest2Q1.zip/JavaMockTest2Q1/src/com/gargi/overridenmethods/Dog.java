package com.gargi.overridenmethods;

public class Dog extends Animal{
	
	public void makeSound() {
		System.out.println("Dog is barking woof woof");
	}
	

}
