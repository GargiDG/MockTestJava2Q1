package com.gargi.overridenmethods;

public class Cow extends Animal {
	public void makeSound() {
		System.out.println("Cow moos");
	}
	

}
